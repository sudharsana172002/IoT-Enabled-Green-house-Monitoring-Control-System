Src/i2c.o: ../Src/i2c.c ../Inc/i2c.h ../Inc/stm32f4xx.h \
 ../Inc/stm32f407xx.h ../Inc/core_cm4.h ../Inc/cmsis_version.h \
 ../Inc/cmsis_compiler.h ../Inc/cmsis_gcc.h ../Inc/mpu_armv7.h \
 ../Inc/system_stm32f4xx.h
../Inc/i2c.h:
../Inc/stm32f4xx.h:
../Inc/stm32f407xx.h:
../Inc/core_cm4.h:
../Inc/cmsis_version.h:
../Inc/cmsis_compiler.h:
../Inc/cmsis_gcc.h:
../Inc/mpu_armv7.h:
../Inc/system_stm32f4xx.h:
